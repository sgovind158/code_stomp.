





export const  Introduction = ["History of Web and evolution of Web 3.0"]

export const  Understanding =["Blockchain Overview","What is Augmented Reality (AR)","Blockchain Functional layers","Fundamentals of Consensus Algorithm","Various Consensus in Blockchain"]

export const   Overview = ["Introduction to Polkadot"] 

export const  Mechanism  = ["How Can You Get Started With Metaverse?","Unity3D","Unreal Engine"]

export const  Detail =["Components of Polkadot","Staking in Polkadot","Substrate Overview",]



export const  UsingPolkadot  = ["DOT Overview","Major Functions of DOT","Participation in Polkadot","How To Choose a Polkadot Wallet?","Polkadot Wallets to Store Your DOT Coins","Polkadot ATMs"]

export const TopProject = ["Acala","Phala Network","Moonbeam","Darwinia Network","PolkaFoundry"]

export const  OtherBlockchains = ["Polkadot vs Eth 2.0","Polkadot vs Kusama","Additional Information: Kusama Auctions","Polkadot vs Cosmos","Other Comparisons: Eth 1.x and Binance Smart Chain","Polkadot Vs Other Blockchain Protocols"]

export const PolkadotGoverence = ["Thorchain","IDEX","bXZ"]

export const  CertifiedMetaverse =["There will be an online training followed by a multiple-choice exam of 100 marks","You need to acquire 60+ marks to clear the exam","If you fail, you can retake the exam after one day","You can take the exam no more than 3 times","If you fail to acquire 60+ marks even after three attempts, then you need to contact us to get assistance for clearing the exam"]